package com.mumfrey.liteloader.transformers.event.json;

public enum JsonInjectionShiftType
{
	BEFORE,
	AFTER
}
