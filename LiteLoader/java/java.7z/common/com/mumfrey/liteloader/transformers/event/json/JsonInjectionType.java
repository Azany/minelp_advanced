package com.mumfrey.liteloader.transformers.event.json;

public enum JsonInjectionType
{
	INVOKE,
	INVOKESTRING,
	FIELD,
	RETURN,
	HEAD,
	CUSTOM;
}
